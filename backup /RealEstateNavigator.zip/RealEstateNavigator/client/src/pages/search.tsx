import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import SearchResults from "./search-results";

export default function Search() {
  return <SearchResults />;
}

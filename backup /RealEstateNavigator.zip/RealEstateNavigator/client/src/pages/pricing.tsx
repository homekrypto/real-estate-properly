import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { CheckCircle, Crown, Star, Globe, BarChart3, Users, Headphones } from "lucide-react";

export default function Pricing() {
  const { t } = useTranslation();
  const [isAnnual, setIsAnnual] = useState(true);

  const plans = [
    {
      name: "Global 20",
      description: "Perfect for independent agents",
      monthlyPrice: 150,
      annualPrice: 120,
      savings: 180,
      features: [
        "Up to 20 listings",
        "Global audience in 35 countries",
        "80+ additional portals",
        "CRM integration",
        "Basic analytics",
        "Email support"
      ],
      popular: false,
      cta: "Get Started"
    },
    {
      name: "Global 50",
      description: "For growing agencies",
      monthlyPrice: 200,
      annualPrice: 160,
      savings: 240,
      features: [
        "Up to 50 listings",
        "Global audience in 35 countries",
        "80+ additional portals",
        "Advanced CRM integration",
        "Advanced analytics & reporting",
        "Priority support",
        "Luxury portal access",
        "AI-powered tools"
      ],
      popular: true,
      cta: "Get Started"
    },
    {
      name: "Global 100",
      description: "For established agencies",
      monthlyPrice: 300,
      annualPrice: 240,
      savings: 360,
      features: [
        "Up to 100 listings",
        "Global audience in 35 countries",
        "80+ additional portals",
        "Full CRM integration",
        "Complete analytics suite",
        "Dedicated account manager",
        "Premium luxury portals",
        "Advanced AI tools",
        "Custom integrations"
      ],
      popular: false,
      cta: "Get Started"
    }
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />
      
      <div className="pt-20">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-forest-50 via-white to-gold-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="font-luxury text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6">
                {t("pricing.title")}
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed mb-8">
                {t("pricing.description")}
              </p>
              
              {/* Billing Toggle */}
              <div className="flex items-center justify-center space-x-4 mb-12">
                <span className={`text-lg ${!isAnnual ? 'text-gray-900 dark:text-white font-medium' : 'text-gray-600 dark:text-gray-400'}`}>
                  {t("pricing.monthly")}
                </span>
                <Switch 
                  checked={isAnnual} 
                  onCheckedChange={setIsAnnual}
                  className="data-[state=checked]:bg-forest-600"
                />
                <span className={`text-lg ${isAnnual ? 'text-forest-600 dark:text-forest-400 font-medium' : 'text-gray-600 dark:text-gray-400'}`}>
                  {t("pricing.annual")}
                </span>
                <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                  Save 20%
                </Badge>
              </div>
            </div>
          </div>
        </section>

        {/* Pricing Cards */}
        <section className="py-20 bg-white dark:bg-gray-900">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
              {plans.map((plan, index) => (
                <Card 
                  key={plan.name}
                  className={`relative overflow-hidden hover:shadow-2xl transition-all duration-300 ${
                    plan.popular 
                      ? 'border-2 border-gold-400 dark:border-gold-500 shadow-xl scale-105' 
                      : 'border border-gray-200 dark:border-gray-700'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-gradient-to-r from-gold-500 to-gold-600 text-white px-6 py-2 text-sm font-semibold">
                        <Star className="w-4 h-4 mr-1" />
                        Most Popular
                      </Badge>
                    </div>
                  )}
                  
                  <CardContent className="p-8 pt-12">
                    <div className="text-center mb-8">
                      <div className="flex items-center justify-center mb-4">
                        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                          plan.popular 
                            ? 'bg-gradient-to-br from-gold-500 to-gold-600' 
                            : 'bg-gradient-to-br from-forest-600 to-forest-700'
                        }`}>
                          {plan.popular ? (
                            <Crown className="text-white h-8 w-8" />
                          ) : (
                            <Globe className="text-white h-8 w-8" />
                          )}
                        </div>
                      </div>
                      
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{plan.name}</h3>
                      <p className="text-gray-600 dark:text-gray-400 mb-6">{plan.description}</p>
                      
                      <div className="mb-4">
                        <div className="text-4xl font-bold text-forest-600 dark:text-forest-400 mb-2">
                          ${isAnnual ? plan.annualPrice : plan.monthlyPrice}
                          <span className="text-lg font-normal text-gray-600 dark:text-gray-400">/mo</span>
                        </div>
                        {isAnnual && (
                          <p className="text-sm text-green-600 dark:text-green-400">
                            Save ${plan.savings} annually
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <ul className="space-y-4 mb-8">
                      {plan.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start space-x-3">
                          <CheckCircle className="text-forest-600 dark:text-forest-400 h-5 w-5 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Button 
                      className={`w-full py-3 font-semibold transition-all duration-200 ${
                        plan.popular
                          ? 'bg-gradient-to-r from-forest-600 to-forest-700 hover:from-forest-700 hover:to-forest-800 text-white shadow-lg hover:shadow-xl'
                          : 'bg-gray-900 dark:bg-gray-700 text-white hover:bg-gray-800 dark:hover:bg-gray-600'
                      }`}
                    >
                      {plan.cta}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Enterprise Section */}
        <section className="py-20 bg-gray-50 dark:bg-gray-800">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="font-luxury text-4xl font-bold text-gray-900 dark:text-white mb-6">
                Need Something More?
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Custom enterprise solutions for large agencies and developers
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
              {/* Enterprise Plan */}
              <Card className="p-8 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700">
                <CardContent className="p-0">
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-forest-600 to-forest-800 rounded-2xl flex items-center justify-center mr-4">
                      <Users className="text-white h-8 w-8" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Enterprise</h3>
                      <p className="text-gray-600 dark:text-gray-400">For large agencies</p>
                    </div>
                  </div>
                  
                  <ul className="space-y-4 mb-8">
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="text-forest-600 dark:text-forest-400 h-5 w-5" />
                      <span className="text-gray-700 dark:text-gray-300">Unlimited listings</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="text-forest-600 dark:text-forest-400 h-5 w-5" />
                      <span className="text-gray-700 dark:text-gray-300">White-label solutions</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="text-forest-600 dark:text-forest-400 h-5 w-5" />
                      <span className="text-gray-700 dark:text-gray-300">Custom API integrations</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="text-forest-600 dark:text-forest-400 h-5 w-5" />
                      <span className="text-gray-700 dark:text-gray-300">Dedicated infrastructure</span>
                    </li>
                  </ul>
                  
                  <Button className="w-full bg-gradient-to-r from-forest-600 to-forest-700 hover:from-forest-700 hover:to-forest-800 text-white">
                    Contact Sales
                  </Button>
                </CardContent>
              </Card>

              {/* Developer Solutions */}
              <Card className="p-8 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700">
                <CardContent className="p-0">
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-gold-500 to-gold-600 rounded-2xl flex items-center justify-center mr-4">
                      <BarChart3 className="text-white h-8 w-8" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Developer</h3>
                      <p className="text-gray-600 dark:text-gray-400">For property developers</p>
                    </div>
                  </div>
                  
                  <ul className="space-y-4 mb-8">
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="text-forest-600 dark:text-forest-400 h-5 w-5" />
                      <span className="text-gray-700 dark:text-gray-300">Project management tools</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="text-forest-600 dark:text-forest-400 h-5 w-5" />
                      <span className="text-gray-700 dark:text-gray-300">Unit inventory management</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="text-forest-600 dark:text-forest-400 h-5 w-5" />
                      <span className="text-gray-700 dark:text-gray-300">Featured project placement</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="text-forest-600 dark:text-forest-400 h-5 w-5" />
                      <span className="text-gray-700 dark:text-gray-300">Luxury portal distribution</span>
                    </li>
                  </ul>
                  
                  <Button className="w-full bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 bg-white dark:bg-gray-900">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="font-luxury text-4xl font-bold text-gray-900 dark:text-white mb-4">
                Frequently Asked Questions
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Everything you need to know about our plans and pricing
              </p>
            </div>

            <div className="max-w-4xl mx-auto space-y-8">
              {[
                {
                  question: "What portals are included in the global network?",
                  answer: "Our network includes 80+ premium portals including Mansion Global, Wall Street Journal Real Estate, Zoopla, Immowelt, Juwai, Primelocation, and many more across 35+ countries."
                },
                {
                  question: "Can I upgrade or downgrade my plan?",
                  answer: "Yes, you can change your plan at any time. Upgrades take effect immediately, and downgrades take effect at the start of your next billing cycle."
                },
                {
                  question: "Is there a setup fee?",
                  answer: "No, there are no setup fees. You can start publishing your listings immediately after signup."
                },
                {
                  question: "Do you offer a free trial?",
                  answer: "Yes, we offer a 14-day free trial with full access to all features so you can experience the platform before committing."
                },
                {
                  question: "What kind of support do you provide?",
                  answer: "We provide email support for all plans, priority support for Global 50+, and dedicated account management for Global 100 and Enterprise plans."
                }
              ].map((faq, index) => (
                <Card key={index} className="p-6 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                  <CardContent className="p-0">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                      {faq.question}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      {faq.answer}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-forest-600 to-forest-800 dark:from-forest-700 dark:to-forest-900">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <div className="max-w-3xl mx-auto">
              <h2 className="font-luxury text-4xl lg:text-5xl font-bold text-white mb-6">
                Ready to Go Global?
              </h2>
              <p className="text-xl text-forest-100 mb-8">
                Start your 14-day free trial today and see why over 200,000 agents choose Properly
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="px-8 py-4 bg-white text-forest-600 hover:bg-gray-100 font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-200">
                  Start Free Trial
                </Button>
                <Button variant="outline" className="px-8 py-4 text-lg border-white text-white hover:bg-white/10">
                  Contact Sales
                </Button>
              </div>
            </div>
          </div>
        </section>
      </div>

      <Footer />
    </div>
  );
}

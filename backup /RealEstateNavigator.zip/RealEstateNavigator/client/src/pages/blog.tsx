import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Calendar, Clock, ArrowRight, TrendingUp, Globe, BarChart3 } from "lucide-react";
import { useState } from "react";

export default function Blog() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");

  const { data: blogPosts = [], isLoading } = useQuery({
    queryKey: ["/api/blog"],
  });

  const categories = [
    "Market Analysis",
    "Investment Guide",
    "Sustainability",
    "Technology",
    "Legal",
    "Trends"
  ];

  const featuredPost = blogPosts[0];
  const remainingPosts = blogPosts.slice(1);

  const filteredPosts = remainingPosts.filter((post: any) => {
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || selectedCategory === "all" || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />
      
      <div className="pt-20">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-forest-50 via-white to-gold-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="font-luxury text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6">
                Market <span className="text-forest-600 dark:text-forest-400">Insights</span>
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed mb-8">
                Stay informed with the latest trends, expert analysis, and insights in international luxury real estate
              </p>
              
              {/* Search and Filter */}
              <div className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <Input
                    placeholder="Search articles..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 py-3"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full sm:w-48 py-3">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Article */}
        {featuredPost && !isLoading && (
          <section className="py-20 bg-white dark:bg-gray-900">
            <div className="container mx-auto px-4 lg:px-8">
              <div className="text-center mb-12">
                <h2 className="font-luxury text-4xl font-bold text-gray-900 dark:text-white mb-4">
                  Featured Article
                </h2>
              </div>

              <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 max-w-4xl mx-auto">
                <div className="grid md:grid-cols-2 gap-0">
                  <div className="relative">
                    <img 
                      src={featuredPost.featuredImage} 
                      alt={featuredPost.title}
                      className="w-full h-full object-cover min-h-[300px]" 
                    />
                    <Badge className="absolute top-4 left-4 bg-forest-600 text-white">
                      Featured
                    </Badge>
                  </div>
                  <CardContent className="p-8 flex flex-col justify-center">
                    <div className="flex items-center space-x-4 mb-4">
                      <Badge variant="secondary" className="text-forest-600 dark:text-forest-400">
                        {featuredPost.category}
                      </Badge>
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <Calendar className="mr-1 h-4 w-4" />
                        {new Date(featuredPost.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                    <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                      {featuredPost.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
                      {featuredPost.excerpt}
                    </p>
                    <Button 
                      onClick={() => setLocation(`/blog/${featuredPost.slug}`)}
                      className="bg-gradient-to-r from-forest-600 to-forest-700 hover:from-forest-700 hover:to-forest-800 text-white self-start"
                    >
                      Read Full Article
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </div>
              </Card>
            </div>
          </section>
        )}

        {/* Articles Grid */}
        <section className="py-20 bg-gray-50 dark:bg-gray-800">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="flex justify-between items-center mb-12">
              <h2 className="font-luxury text-4xl font-bold text-gray-900 dark:text-white">
                Latest Articles
              </h2>
              <div className="text-gray-600 dark:text-gray-400">
                {filteredPosts.length} articles found
              </div>
            </div>

            {isLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <Skeleton className="w-full h-48" />
                    <CardContent className="p-6">
                      <Skeleton className="h-4 w-24 mb-3" />
                      <Skeleton className="h-6 w-full mb-3" />
                      <Skeleton className="h-4 w-full mb-4" />
                      <Skeleton className="h-4 w-full" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredPosts.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-32 h-32 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Search className="h-16 w-16 text-gray-400" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                  No Articles Found
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-md mx-auto">
                  We couldn't find any articles matching your search criteria. Try adjusting your search terms or category filter.
                </p>
                <Button 
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("");
                  }}
                  className="bg-gradient-to-r from-forest-600 to-forest-700 hover:from-forest-700 hover:to-forest-800 text-white"
                >
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredPosts.map((post: any) => (
                  <Card key={post.id} className="overflow-hidden hover:shadow-2xl transition-all duration-300 group bg-white dark:bg-gray-900">
                    <div className="relative">
                      <img 
                        src={post.featuredImage} 
                        alt={post.title}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" 
                      />
                      <div className="absolute top-4 left-4">
                        <Badge variant="secondary" className="bg-white/90 dark:bg-gray-800/90">
                          {post.category}
                        </Badge>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-4 mb-3 text-sm text-gray-500 dark:text-gray-400">
                        <div className="flex items-center">
                          <Calendar className="mr-1 h-4 w-4" />
                          {new Date(post.createdAt).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <Clock className="mr-1 h-4 w-4" />
                          5 min read
                        </div>
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-forest-600 dark:group-hover:text-forest-400 transition-colors line-clamp-2">
                        {post.title}
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed mb-4 line-clamp-3">
                        {post.excerpt}
                      </p>
                      <Button 
                        variant="outline" 
                        onClick={() => setLocation(`/blog/${post.slug}`)}
                        className="w-full group-hover:bg-forest-50 dark:group-hover:bg-forest-900/20 group-hover:border-forest-600 dark:group-hover:border-forest-400"
                      >
                        Read More
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="py-20 bg-white dark:bg-gray-900">
          <div className="container mx-auto px-4 lg:px-8">
            <Card className="bg-gradient-to-r from-forest-600 to-forest-800 dark:from-forest-700 dark:to-forest-900 text-white">
              <CardContent className="p-12 text-center">
                <div className="max-w-2xl mx-auto">
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <TrendingUp className="h-8 w-8 text-white" />
                  </div>
                  <h2 className="font-luxury text-4xl font-bold mb-4">
                    Stay Ahead of the Market
                  </h2>
                  <p className="text-xl text-forest-100 mb-8">
                    Subscribe to our newsletter and get the latest luxury real estate insights delivered to your inbox
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                    <Input 
                      placeholder="Enter your email"
                      className="bg-white/10 border-white/20 text-white placeholder:text-forest-100 flex-1"
                    />
                    <Button className="bg-white text-forest-600 hover:bg-gray-100 font-semibold">
                      Subscribe
                    </Button>
                  </div>
                  <p className="text-sm text-forest-200 mt-4">
                    No spam, unsubscribe at any time.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Categories Section */}
        <section className="py-20 bg-gray-50 dark:bg-gray-800">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="font-luxury text-4xl font-bold text-gray-900 dark:text-white mb-4">
                Explore by Category
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Dive deeper into specific topics that matter to your real estate business
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categories.map((category) => (
                <Card 
                  key={category}
                  className="p-6 hover:shadow-xl transition-all duration-300 cursor-pointer group bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700"
                  onClick={() => setSelectedCategory(category)}
                >
                  <CardContent className="p-0">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white group-hover:text-forest-600 dark:group-hover:text-forest-400 transition-colors">
                        {category}
                      </h3>
                      <ArrowRight className="h-5 w-5 text-gray-400 group-hover:text-forest-600 dark:group-hover:text-forest-400 transition-colors" />
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 text-sm">
                      {blogPosts.filter((post: any) => post.category === category).length} articles
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </div>

      <Footer />
    </div>
  );
}

import {
  users,
  countries,
  regions,
  cities,
  properties,
  savedProperties,
  messages,
  blogPosts,
  verificationTokens,
  subscriptionPlans,
  propertyInquiries,
  type User,
  type UpsertUser,
  type Country,
  type InsertCountry,
  type Region,
  type InsertRegion,
  type City,
  type InsertCity,
  type Property,
  type InsertProperty,
  type SavedProperty,
  type InsertSavedProperty,
  type Message,
  type InsertMessage,
  type BlogPost,
  type InsertBlogPost,
  type VerificationToken,
  type InsertVerificationToken,
  type SubscriptionPlan,
  type PropertyInquiry,
  type InsertPropertyInquiry,
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  updateUserStatus(id: string, status: string): Promise<User>;
  updateUserSubscription(id: string, subscription: {
    status: string;
    tier?: string;
    subscriptionId?: string;
    customerId?: string;
    currentPeriodEnd?: Date;
  }): Promise<User>;
  
  // Verification token operations
  createVerificationToken(data: InsertVerificationToken): Promise<VerificationToken>;
  getVerificationToken(token: string): Promise<VerificationToken | undefined>;
  markTokenAsUsed(token: string): Promise<void>;
  
  // Subscription operations
  getSubscriptionPlans(): Promise<SubscriptionPlan[]>;
  getSubscriptionPlan(id: string): Promise<SubscriptionPlan | undefined>;
  
  // Property inquiry operations
  createPropertyInquiry(data: InsertPropertyInquiry): Promise<PropertyInquiry>;
  getPropertyInquiries(agentId: string): Promise<PropertyInquiry[]>;
  updateInquiryStatus(id: number, status: string): Promise<void>;
  
  // Country operations
  getCountries(): Promise<Country[]>;
  getCountry(id: number): Promise<Country | undefined>;
  
  // Region operations
  getRegionsByCountry(countryId: number): Promise<Region[]>;
  
  // City operations
  getCitiesByRegion(regionId: number): Promise<City[]>;
  
  // Property operations
  getProperties(filters?: any): Promise<Property[]>;
  getProperty(id: number): Promise<Property | undefined>;
  createProperty(property: InsertProperty): Promise<Property>;
  updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property>;
  getFeaturedProperties(): Promise<Property[]>;
  searchProperties(query: any): Promise<Property[]>;
  incrementViewCount(id: number): Promise<void>;
  
  // Saved properties
  getSavedProperties(userId: string): Promise<SavedProperty[]>;
  saveProperty(data: InsertSavedProperty): Promise<SavedProperty>;
  unsaveProperty(userId: string, propertyId: number): Promise<void>;
  
  // Messages
  getMessages(userId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<void>;
  
  // Blog posts
  getBlogPosts(): Promise<BlogPost[]>;
  getBlogPost(slug: string): Promise<BlogPost | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private countries: Map<number, Country> = new Map();
  private regions: Map<number, Region> = new Map();
  private cities: Map<number, City> = new Map();
  private properties: Map<number, Property> = new Map();
  private savedProperties: Map<number, SavedProperty> = new Map();
  private messages: Map<number, Message> = new Map();
  private blogPosts: Map<number, BlogPost> = new Map();
  private verificationTokens: Map<string, VerificationToken> = new Map();
  
  private currentPropertyId = 1;
  private currentSavedPropertyId = 1;
  private currentMessageId = 1;
  private currentBlogPostId = 1;

  constructor() {
    this.initializeData();
    this.initializeTestUsers();
  }

  private initializeTestUsers() {
    // Create test users for the corrective mandate testing
    const seekerUser: User = {
      id: "user_seeker_test",
      email: "seeker@example.com",
      firstName: "Test",
      lastName: "Seeker",
      fullName: "Test Seeker",
      imageUrl: "",
      role: "seeker",
      status: "verified",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    const agentUser: User = {
      id: "user_agent_test",
      email: "agent@example.com",
      firstName: "Test",
      lastName: "Agent",
      fullName: "Test Agent",
      imageUrl: "",
      role: "agent",
      status: "verified",
      agencyName: "Test Agency",
      phone: "+1234567890",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.users.set(seekerUser.id, seekerUser);
    this.users.set(agentUser.id, agentUser);
    
    console.log("[INFO] Test users created: seeker@example.com (verified), agent@example.com (verified)");
  }

  private initializeData() {
    // Initialize countries
    const countriesData: InsertCountry[] = [
      { name: "Spain", code: "ES", flag: "🇪🇸", currency: "EUR" },
      { name: "Italy", code: "IT", flag: "🇮🇹", currency: "EUR" },
      { name: "Portugal", code: "PT", flag: "🇵🇹", currency: "EUR" },
      { name: "Greece", code: "GR", flag: "🇬🇷", currency: "EUR" },
      { name: "Dominican Republic", code: "DO", flag: "🇩🇴", currency: "DOP" },
      { name: "France", code: "FR", flag: "🇫🇷", currency: "EUR" },
      { name: "Germany", code: "DE", flag: "🇩🇪", currency: "EUR" },
      { name: "United Kingdom", code: "GB", flag: "🇬🇧", currency: "GBP" },
    ];

    countriesData.forEach((country, index) => {
      this.countries.set(index + 1, { 
        id: index + 1, 
        ...country, 
        createdAt: new Date() 
      });
    });

    // Initialize regions
    const regionsData: InsertRegion[] = [
      { name: "Catalonia", countryId: 1 },
      { name: "Andalusia", countryId: 1 },
      { name: "Valencia", countryId: 1 },
      { name: "Tuscany", countryId: 2 },
      { name: "Lombardy", countryId: 2 },
      { name: "Algarve", countryId: 3 },
      { name: "Lisbon District", countryId: 3 },
      { name: "Attica", countryId: 4 },
      { name: "Crete", countryId: 4 },
      { name: "Santo Domingo", countryId: 5 },
      { name: "Punta Cana", countryId: 5 },
    ];

    regionsData.forEach((region, index) => {
      this.regions.set(index + 1, { 
        id: index + 1, 
        ...region, 
        createdAt: new Date() 
      });
    });

    // Initialize cities
    const citiesData: InsertCity[] = [
      { name: "Barcelona", regionId: 1, latitude: "41.3851", longitude: "2.1734" },
      { name: "Marbella", regionId: 2, latitude: "36.5097", longitude: "-4.8864" },
      { name: "Valencia", regionId: 3, latitude: "39.4699", longitude: "-0.3763" },
      { name: "Florence", regionId: 4, latitude: "43.7696", longitude: "11.2558" },
      { name: "Milan", regionId: 5, latitude: "45.4642", longitude: "9.1900" },
      { name: "Lagos", regionId: 6, latitude: "37.1021", longitude: "-8.6756" },
      { name: "Lisbon", regionId: 7, latitude: "38.7223", longitude: "-9.1393" },
      { name: "Athens", regionId: 8, latitude: "37.9838", longitude: "23.7275" },
      { name: "Santorini", regionId: 9, latitude: "36.3932", longitude: "25.4615" },
      { name: "Santo Domingo", regionId: 10, latitude: "18.4861", longitude: "-69.9312" },
    ];

    citiesData.forEach((city, index) => {
      this.cities.set(index + 1, { 
        id: index + 1, 
        ...city, 
        createdAt: new Date() 
      });
    });

    // Initialize blog posts
    const blogPostsData: InsertBlogPost[] = [
      {
        title: "European Luxury Market Trends 2025",
        slug: "european-luxury-market-trends-2025",
        excerpt: "Discover the emerging trends shaping luxury real estate across Europe, from sustainable design to smart home technology.",
        content: "The European luxury real estate market continues to evolve...",
        category: "Market Analysis",
        authorId: "admin",
        featuredImage: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isPublished: true,
      },
      {
        title: "International Property Investment Guide",
        slug: "international-property-investment-guide",
        excerpt: "Essential strategies for international property investment, including tax implications and market selection criteria.",
        content: "Investing in international real estate requires careful planning...",
        category: "Investment Guide",
        authorId: "admin",
        featuredImage: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isPublished: true,
      },
      {
        title: "Sustainable Luxury: The Future is Green",
        slug: "sustainable-luxury-future-green",
        excerpt: "How eco-friendly features and sustainable design are reshaping the luxury property market worldwide.",
        content: "Sustainability is becoming increasingly important in luxury real estate...",
        category: "Sustainability",
        authorId: "admin",
        featuredImage: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isPublished: true,
      },
    ];

    blogPostsData.forEach((post, index) => {
      this.blogPosts.set(index + 1, { 
        id: index + 1, 
        ...post, 
        createdAt: new Date(),
        updatedAt: new Date()
      });
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existing = this.users.get(userData.id);
    const user: User = {
      ...userData,
      createdAt: existing?.createdAt || new Date(),
      updatedAt: new Date(),
    };
    this.users.set(userData.id, user);
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async updateUserStatus(id: string, status: string): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    const updatedUser: User = {
      ...user,
      status,
      updatedAt: new Date(),
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserSubscription(id: string, subscription: {
    status: string;
    tier?: string;
    subscriptionId?: string;
    customerId?: string;
    currentPeriodEnd?: Date;
  }): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    const updatedUser: User = {
      ...user,
      subscriptionStatus: subscription.status,
      subscriptionTier: subscription.tier,
      subscriptionId: subscription.subscriptionId,
      customerId: subscription.customerId,
      currentPeriodEnd: subscription.currentPeriodEnd,
      updatedAt: new Date(),
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Verification token operations
  async createVerificationToken(data: InsertVerificationToken): Promise<VerificationToken> {
    const token: VerificationToken = {
      ...data,
      isUsed: false,
      createdAt: new Date(),
    };
    this.verificationTokens.set(data.token, token);
    return token;
  }

  async getVerificationToken(token: string): Promise<VerificationToken | undefined> {
    return this.verificationTokens.get(token);
  }

  async markTokenAsUsed(token: string): Promise<void> {
    const verificationToken = this.verificationTokens.get(token);
    if (verificationToken) {
      verificationToken.isUsed = true;
      this.verificationTokens.set(token, verificationToken);
    }
  }

  // Subscription operations
  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    // Mock subscription plans
    return [
      {
        id: "bronze",
        name: "Bronze",
        description: "Perfect for independent agents",
        monthlyPrice: 40,
        annualPrice: 432,
        propertyLimit: 10,
        features: ["Up to 10 listings", "Global audience in 35 countries", "80+ additional portals", "Basic analytics", "Email support"],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "silver",
        name: "Silver",
        description: "For growing agencies",
        monthlyPrice: 60,
        annualPrice: 648,
        propertyLimit: 25,
        features: ["Up to 25 listings", "Global audience in 35 countries", "80+ additional portals", "Advanced CRM integration", "Advanced analytics & reporting", "Priority support"],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "gold",
        name: "Gold",
        description: "For established agencies",
        monthlyPrice: 80,
        annualPrice: 864,
        propertyLimit: 35,
        features: ["Up to 35 listings", "Global audience in 35 countries", "80+ additional portals", "Advanced CRM integration", "Advanced analytics & reporting", "Priority support", "API access"],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];
  }

  async getSubscriptionPlan(id: string): Promise<SubscriptionPlan | undefined> {
    const plans = await this.getSubscriptionPlans();
    return plans.find(plan => plan.id === id);
  }

  // Property inquiry operations
  async createPropertyInquiry(data: InsertPropertyInquiry): Promise<PropertyInquiry> {
    const inquiry: PropertyInquiry = {
      id: Date.now(),
      ...data,
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    return inquiry;
  }

  async getPropertyInquiries(agentId: string): Promise<PropertyInquiry[]> {
    return [];
  }

  async updateInquiryStatus(id: number, status: string): Promise<void> {
    // Mock implementation
  }

  // Country operations
  async getCountries(): Promise<Country[]> {
    return Array.from(this.countries.values());
  }

  async getCountry(id: number): Promise<Country | undefined> {
    return this.countries.get(id);
  }

  // Region operations
  async getRegionsByCountry(countryId: number): Promise<Region[]> {
    return Array.from(this.regions.values()).filter(region => region.countryId === countryId);
  }

  // City operations
  async getCitiesByRegion(regionId: number): Promise<City[]> {
    return Array.from(this.cities.values()).filter(city => city.regionId === regionId);
  }

  // Property operations
  async getProperties(filters?: any): Promise<Property[]> {
    let result = Array.from(this.properties.values()).filter(p => p.isActive);
    
    if (filters) {
      if (filters.countryId) {
        result = result.filter(p => p.countryId === parseInt(filters.countryId));
      }
      if (filters.propertyType) {
        result = result.filter(p => p.propertyType === filters.propertyType);
      }
      if (filters.listingType) {
        result = result.filter(p => p.listingType === filters.listingType);
      }
      if (filters.minPrice) {
        result = result.filter(p => parseFloat(p.price) >= parseFloat(filters.minPrice));
      }
      if (filters.maxPrice) {
        result = result.filter(p => parseFloat(p.price) <= parseFloat(filters.maxPrice));
      }
      if (filters.bedrooms) {
        result = result.filter(p => p.bedrooms >= parseInt(filters.bedrooms));
      }
      if (filters.bathrooms) {
        result = result.filter(p => p.bathrooms >= parseInt(filters.bathrooms));
      }
    }

    return result;
  }

  async getProperty(id: number): Promise<Property | undefined> {
    return this.properties.get(id);
  }

  async createProperty(property: InsertProperty): Promise<Property> {
    const id = this.currentPropertyId++;
    const newProperty: Property = {
      id,
      ...property,
      viewCount: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.properties.set(id, newProperty);
    return newProperty;
  }

  async updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property> {
    const existing = this.properties.get(id);
    if (!existing) throw new Error("Property not found");
    
    const updated: Property = {
      ...existing,
      ...property,
      updatedAt: new Date(),
    };
    this.properties.set(id, updated);
    return updated;
  }

  async getFeaturedProperties(): Promise<Property[]> {
    return Array.from(this.properties.values())
      .filter(p => p.isActive && p.isFeatured)
      .slice(0, 6);
  }

  async searchProperties(query: any): Promise<Property[]> {
    return this.getProperties(query);
  }

  async incrementViewCount(id: number): Promise<void> {
    const property = this.properties.get(id);
    if (property) {
      property.viewCount = (property.viewCount || 0) + 1;
      this.properties.set(id, property);
    }
  }

  // Saved properties
  async getSavedProperties(userId: string): Promise<SavedProperty[]> {
    return Array.from(this.savedProperties.values()).filter(sp => sp.userId === userId);
  }

  async saveProperty(data: InsertSavedProperty): Promise<SavedProperty> {
    const id = this.currentSavedPropertyId++;
    const savedProperty: SavedProperty = {
      id,
      ...data,
      createdAt: new Date(),
    };
    this.savedProperties.set(id, savedProperty);
    return savedProperty;
  }

  async unsaveProperty(userId: string, propertyId: number): Promise<void> {
    const toDelete = Array.from(this.savedProperties.entries())
      .find(([_, sp]) => sp.userId === userId && sp.propertyId === propertyId);
    
    if (toDelete) {
      this.savedProperties.delete(toDelete[0]);
    }
  }

  // Messages
  async getMessages(userId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => m.toUserId === userId || m.fromUserId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const newMessage: Message = {
      id,
      ...message,
      isRead: false,
      createdAt: new Date(),
    };
    this.messages.set(id, newMessage);
    return newMessage;
  }

  async markMessageAsRead(id: number): Promise<void> {
    const message = this.messages.get(id);
    if (message) {
      message.isRead = true;
      this.messages.set(id, message);
    }
  }

  // Blog posts
  async getBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values())
      .filter(post => post.isPublished)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getBlogPost(slug: string): Promise<BlogPost | undefined> {
    return Array.from(this.blogPosts.values()).find(post => post.slug === slug && post.isPublished);
  }
}

export const storage = new MemStorage();
